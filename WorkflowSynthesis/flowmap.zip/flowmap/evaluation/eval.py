##This script generates an excel sheet for evaluating workflows

import os

def main():
    workingdir = r"C:\Users\schei008\.matplotlib\Documents\github\QuAnGIS\WorkflowSynthesis\flowmap"
    print(os.listdir(workingdir))

    #f = open("demofile.txt", "r")


if __name__ == '__main__':
    main()